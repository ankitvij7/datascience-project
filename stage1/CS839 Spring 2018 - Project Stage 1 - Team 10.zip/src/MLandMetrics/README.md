#Needed Python Libraries:
Using PyCharm include in your interpreters:
1. python - 3.6
1. scikit-learn - 0.19.1
1. numpy - 1.14.1
1. scipi - 1.0.0

